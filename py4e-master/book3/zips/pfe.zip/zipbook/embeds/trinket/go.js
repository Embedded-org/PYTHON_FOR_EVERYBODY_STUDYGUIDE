anchors.options = {
  placement: 'right',
  visible: 'always',
  icon: '#'
};
anchors.add('h2, h3, .anchor');
anchors.remove('.no-anchor');
$(document).foundation();